#include <61header.h>

int main(int argc, char *argv[]){
    if(argc < 2){
        fprintf(stderr, "error: 命令行参数个数错误!\n");
        return 1;
    }
    printf("argc = %d\n", argc);
    for(int i = 0; i < argc; i++){
        printf("第%d个命令行参数是:%s\n", (i + 1), argv[i]);    
    }
    int num;
    sscanf(argv[1], "%d", &num);
    printf("num = %d\n", num);
    return 0;
}
