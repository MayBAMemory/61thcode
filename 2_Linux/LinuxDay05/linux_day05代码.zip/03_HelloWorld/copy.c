#include <61header.h>

// 将src文件复制到目标dest,若dest存在则直接覆盖
void copy_file(const char *src, const char *dest) {
    FILE *src_fp = fopen(src, "r");        // b在Linux平台下加不加都无所谓
    //if (src_fp == NULL) {
    //    // 将参数拼到当前errno的错误信息上
    //    perror("fopen src");
    //    exit(1);
    //}
    ERROR_CHECK(src_fp, NULL, "fopen src");

    FILE *dest_fp = fopen(dest, "w");
    if (dest_fp == NULL) {
        perror("fopen dest");
        fclose(src_fp);  // 关闭已打开的源文件
        exit(1);
    }

    // 用于临时存储数据的中转站
    char buf[1024] = { 0 }; 
    size_t count;

    // 从源文件读取数据并写入目标文件
    while ((count = fread(buf, 1, sizeof(buf), src_fp)) > 0) {
        fwrite(buf, 1, count, dest_fp);
    }

    // 关闭文件流
    fclose(src_fp);
    fclose(dest_fp);
}

/*Usage: copy src dest */
int main(int argc, char *argv[]) {
    //if (argc != 3) {
    //    fprintf(stderr, "args error!\n");
    //    exit(1);
    //}
    ARGS_CHECK(argc, 3);
    copy_file(argv[1], argv[2]);
    return 0;
}
