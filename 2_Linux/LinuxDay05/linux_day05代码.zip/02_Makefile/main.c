#include <stdio.h>
#include "compute.h"

int main(void){
    printf("1 + 1 = %d\n", add(1, 1));
    printf("1 - 1 = %d\n", sub(1, 1));
    printf("2 * 2 = %d\n", mul(2, 2));
    printf("10 / 2 = %d\n", div(10, 2));
    return 0;
}

