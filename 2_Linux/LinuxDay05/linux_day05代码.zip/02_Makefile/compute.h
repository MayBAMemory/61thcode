#ifndef __WD_MY_COMPUTE_H
#define __WD_MY_COMPUTE_H     

int add(int a, int b);  // 加
int sub(int a, int b);  // 减
int mul(int a, int b);  // 乘
int div(int a, int b);  // 除

#endif
