#include <stdio.h>
#include "compute.h"

int mul(int a, int b){
    return a * b;
}
