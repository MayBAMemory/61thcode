#include <stdio.h>
#include "compute.h"

int sub(int a, int b){
    return a - b;
} 
