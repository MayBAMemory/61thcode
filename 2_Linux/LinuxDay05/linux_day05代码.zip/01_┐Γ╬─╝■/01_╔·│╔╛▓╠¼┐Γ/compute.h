#ifndef __WD_MY_COMPUTE_H
#define __WD_MY_COMPUTE_H     

int add(int a, int b);  // 加
int sub(int a, int b);  // 减

#endif
