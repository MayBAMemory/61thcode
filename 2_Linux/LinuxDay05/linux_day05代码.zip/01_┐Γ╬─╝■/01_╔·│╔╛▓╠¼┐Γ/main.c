#include <stdio.h>
#include "compute.h"

int main(void){
    printf("1 + 1 = %d\n", add(1, 1));
    printf("10 - 5 = %d\n", sub(10, 5));
    return 0;
}

