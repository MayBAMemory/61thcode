#include <stdio.h>
#include "compute.h"

int add(int a, int b){
    printf("你真是一个小笨蛋!\n");
    return a + b;
}
