#include <stdio.h>

int main(int argc, char *argv[]){
    int *p = NULL;
    printf("num = %d\n", *p);
    return 0;
}

