#include <stdio.h>
int test(int n){
    return n + test(n - 1);
}

int main(int argc, char *argv[]){
    test(10);
    return 0;
}

