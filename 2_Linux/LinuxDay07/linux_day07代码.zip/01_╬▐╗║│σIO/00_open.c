#include <61header.h>

/* Usage: ./00_open pathname */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    //int fd = open(argv[1], O_RDWR);
    //int fd = open(argv[1], O_WRONLY | O_TRUNC | O_CREAT, 0777);
    //int fd = open(argv[1], O_RDONLY | O_EXCL | O_CREAT, 0666);
    int fd = open(argv[1], O_EXCL | O_CREAT, 0666);
    ERROR_CHECK(fd, -1, "open");

    // 打印这个文件描述符
    printf("fd = %d\n", fd);

    close(fd);
    return 0;
}

