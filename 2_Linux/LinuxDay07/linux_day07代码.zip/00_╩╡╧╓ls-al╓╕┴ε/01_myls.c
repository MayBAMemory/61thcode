#include <61header.h>

void set_type_mode(mode_t mode, char *tm_str);
void set_time(time_t mtime, char *time_str);

/* Usage: ./01_myls dirname */
int main(int argc, char *argv[]){
    char *path;
    if(argc == 1){
        path = ".";
    }else if(argc == 2){
        path = argv[1];
    }else{
        fprintf(stderr, "args nums error!\n");
        return 1;
    }

    // path是一个目录的路径名
    DIR* dirp = opendir(path);
    ERROR_CHECK(dirp, NULL, "opendir");

    // 切换工作目录为待打印的目录
    int ret = chdir(path);
    ERROR_CHECK(ret, -1, "chdir");

    struct dirent *dp;
    while((dp = readdir(dirp))!= NULL){
        struct stat sb;
        int ret = stat(dp->d_name, &sb);
        ERROR_CHECK(ret, -1, "stat");

        // 1.处理stat的成员st_mode，将它转换成权限和类型字符串
        char tm_str[1024] = {0};
        set_type_mode(sb.st_mode, tm_str);

        // 2.获取用户名和组名
        char *username = getpwuid(sb.st_uid)->pw_name;
        char *gname = getgrgid(sb.st_gid)->gr_name;

        // 3.将时间戳转换为时间字符串
        char time_str[1024] = {0};
        set_time(sb.st_mtim.tv_sec, time_str);

        printf("%s %2lu %s %s %6lu %s %s\n",
               tm_str,
               sb.st_nlink,
               username,
               gname,
               sb.st_size,
               time_str,
               dp->d_name);
    }
    closedir(dirp);
    return 0;
}

// 设置文件类型和权限的字符串
void set_type_mode(mode_t mode, char *tm_str){
    // 1.设置第一个字符表示文件的类型
    switch (mode & S_IFMT) {
    case S_IFBLK:  tm_str[0] = 'b';             break;
    case S_IFCHR:  tm_str[0] = 'c';             break;
    case S_IFDIR:  tm_str[0] = 'd';             break;
    case S_IFIFO:  tm_str[0] = 'p';             break;
    case S_IFLNK:  tm_str[0] = 'l';             break;
    case S_IFREG:  tm_str[0] = '-';             break;
    case S_IFSOCK: tm_str[0] = 's';             break;
    default:       tm_str[0] = '?';             break;
    }

    // 2.设置后面的九个字符表示文件的权限
    // 设置拥有者的权限 
    tm_str[1] = (mode & 0400) ? 'r' : '-';
    tm_str[2] = (mode & 0200) ? 'w' : '-';
    tm_str[3] = (mode & 0100) ? 'x' : '-';
    // 设置拥有者组的权限
    tm_str[4] = (mode & 0040) ? 'r' : '-';
    tm_str[5] = (mode & 0020) ? 'w' : '-';
    tm_str[6] = (mode & 0010) ? 'x' : '-';
    // 设置其它人的权限
    tm_str[7] = (mode & 0004) ? 'r' : '-';
    tm_str[8] = (mode & 0002) ? 'w' : '-';
    tm_str[9] = (mode & 0001) ? 'x' : '-';
    // 不要忘记设置空字符以保证是一个字符串
    tm_str[10] = 0;
}

void set_time(time_t mtime, char *time_str){
    // 构建一个字符串数组来存储月份
    const char month_arr[][10] = {
        "1月", "2月", "3月", "4月", "5月", "6月",
        "7月", "8月", "9月", "10月", "11月", "12月"
    }; 
    struct tm* st_tm = localtime(&mtime);
    sprintf(time_str, "%s %2d %02d:%02d",
            month_arr[st_tm->tm_mon],
            st_tm->tm_mday,
            st_tm->tm_hour,
            st_tm->tm_min);
}
