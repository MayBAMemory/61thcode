#include <61header.h>
#if 0
    基本思路:
    由于排序的依据是文件名的字典顺序
    所以我们可以先构建一个待打印目录下所有文件的dirent结构体指针数组(指针数组排序性能更好)
    然后利用qsort函数给此数组排序
    排好序后
    遍历这个数组,逐一获取stat结构体,然后输出详细信息

    细节问题:
    1.这个dirent结构体指针数组的长度是多少?
    此目录下有几个目录项,它的长度就是多少
    可以考虑给一个比较大的静态数组长度,比如直接给1024,这样的话只要目录项小于1024都可以正常排序
    如果希望动态性更强一些,可以利用动态内存分配这个指针数组
    所以可以遍历两次目录项,第一次先求出目录项的个数也就是指针数组的长度,第二次遍历将目录项结构体指针装进去

    2.关闭目录流的位置问题
    只能在确定不使用任何目录流直接获取的目录项结构体后,才能够关闭目录流

    3.字典排序时,不能直接修改dirent结构体当中的原始文件名数据, 需要使用一个文件名副本用于排序

#endif

void set_type_mode(mode_t mode, char *tm_str);
void set_time(time_t mtime, char *time_str);
static int compare(const void *a, const void *b);
void str_to_lower(char *str);

/* Usage: ./01_myls dirname */
int main(int argc, char *argv[]){
    char *path;
    if(argc == 1){
        path = ".";
    }else if(argc == 2){
        path = argv[1];
    }else{
        fprintf(stderr, "args nums error!\n");
        return 1;
    }

    // path是一个目录的路径名
    DIR* dirp = opendir(path);
    ERROR_CHECK(dirp, NULL, "opendir");

    // 切换工作目录为待打印的目录
    int ret = chdir(path);
    ERROR_CHECK(ret, -1, "chdir");
    

    // 构建dirent结构体指针数组,然后排序
    int count = 0;
    struct dirent *dp;
    // 第一次遍历: 求目录项的个数
    while((dp = readdir(dirp))!= NULL){
        count++;
    }   // while循环结束时,count就是目录项的个数,也就是dirent结构体指针数组的长度,dp此时是NULL
    struct dirent **dir_arr = (struct dirent**)calloc(count, sizeof(struct dirent*));
    ERROR_CHECK(dir_arr, NULL, "calloc dir_arr");
    
    // 倒带目录流指针
    rewinddir(dirp);

    // 第二次遍历: 为指针数组的元素赋值,赋值为目录项结构体
    int idx = 0;
    while((dp = readdir(dirp))!= NULL){
        dir_arr[idx] = dp;
        idx++;
    }   // while循环结束时,目录下的所有目录项结构体都被存入到dir_arr指针数组中了
    
    qsort(dir_arr, count, sizeof(struct dirent*), compare);

    // 接下来的所有操作都基于排好序的dir_arr指针数组
    // 下面的过程和目录流看起来就没有什么关系了
    // 那么可不可以直接close目录流呢?
    //closedir(dirp);

    for(int i = 0; i < count; i++){
        struct stat sb;
        int ret = stat(dir_arr[i]->d_name, &sb);
        ERROR_CHECK(ret, -1, "stat");

        // 1.处理stat的成员st_mode，将它转换成权限和类型字符串
        char tm_str[1024] = {0};
        set_type_mode(sb.st_mode, tm_str);

        // 2.获取用户名和组名
        char *username = getpwuid(sb.st_uid)->pw_name;
        char *gname = getgrgid(sb.st_gid)->gr_name;

        // 3.将时间戳转换为时间字符串
        char time_str[1024] = {0};
        set_time(sb.st_mtim.tv_sec, time_str);

        printf("%s %2lu %s %s %6lu %s %s\n",
               tm_str,
               sb.st_nlink,
               username,
               gname,
               sb.st_size,
               time_str,
               dir_arr[i]->d_name);
    }
    // 一旦关闭目录流,目录项的结构体也会被释放,所以只能在确定所有目录项都不再使用时才能closedir
    closedir(dirp);
    return 0;
}

// 设置文件类型和权限的字符串
void set_type_mode(mode_t mode, char *tm_str){
    // 1.设置第一个字符表示文件的类型
    switch (mode & S_IFMT) {
    case S_IFBLK:  tm_str[0] = 'b';             break;
    case S_IFCHR:  tm_str[0] = 'c';             break;
    case S_IFDIR:  tm_str[0] = 'd';             break;
    case S_IFIFO:  tm_str[0] = 'p';             break;
    case S_IFLNK:  tm_str[0] = 'l';             break;
    case S_IFREG:  tm_str[0] = '-';             break;
    case S_IFSOCK: tm_str[0] = 's';             break;
    default:       tm_str[0] = '?';             break;
    }

    // 2.设置后面的九个字符表示文件的权限
    // 设置拥有者的权限 
    tm_str[1] = (mode & 0400) ? 'r' : '-';
    tm_str[2] = (mode & 0200) ? 'w' : '-';
    tm_str[3] = (mode & 0100) ? 'x' : '-';
    // 设置拥有者组的权限
    tm_str[4] = (mode & 0040) ? 'r' : '-';
    tm_str[5] = (mode & 0020) ? 'w' : '-';
    tm_str[6] = (mode & 0010) ? 'x' : '-';
    // 设置其它人的权限
    tm_str[7] = (mode & 0004) ? 'r' : '-';
    tm_str[8] = (mode & 0002) ? 'w' : '-';
    tm_str[9] = (mode & 0001) ? 'x' : '-';
    // 不要忘记设置空字符以保证是一个字符串
    tm_str[10] = 0;
}

void set_time(time_t mtime, char *time_str){
    // 构建一个字符串数组来存储月份
    const char month_arr[][10] = {
        "1月", "2月", "3月", "4月", "5月", "6月",
        "7月", "8月", "9月", "10月", "11月", "12月"
    }; 
    struct tm* st_tm = localtime(&mtime);
    sprintf(time_str, "%s %2d %02d:%02d",
            month_arr[st_tm->tm_mon],
            st_tm->tm_mday,
            st_tm->tm_hour,
            st_tm->tm_min);
}

// 按照文件名的字典顺序排序dirent结构体指针数组
static int compare(const void *a, const void *b){
    // a和b是什么? 是dirent结构体的二级指针
    struct dirent *dp1 = *(struct dirent**)a;
    struct dirent *dp2 = *(struct dirent**)b;
    
    // 若想实现文件名字母全部小写,需要利用副本实现,不能直接用原始结构体中的文件名
    char fname1[256] = {0};
    char fname2[256] = {0};

    strcpy(fname1, dp1->d_name);
    strcpy(fname2, dp2->d_name);
    str_to_lower(fname1);
    str_to_lower(fname2);

    return strcmp(fname1, fname2);
}

void str_to_lower(char *str){
    while(*str){
        *str = tolower(*str);
        str++;
    }
}
