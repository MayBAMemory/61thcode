#include <61header.h>

/* Usage: ./02_getcwd   */
int main(void){
    // 申请栈内存块不要太吝啬了，至少也要给1024个字节
    //char path[1024] = { 0 };
    //char *ret = getcwd(path, sizeof(path));
    //ERROR_CHECK(ret, NULL, "getcwd");
    //printf("当前工作目录是: %s\n", path);

    // 下列调用方式，getcwd会自己在堆上申请内存，然后返回
    char *path = getcwd(NULL, 0);
    printf("当前工作目录是：%s\n", path);
    free(path);
        
    return 0;
}

