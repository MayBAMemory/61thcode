#include <61header.h>

/* Usage: ./04_mkdir dirname  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    // 新建目录会受掩码影响，这里实际创建的目录权限是775
    int ret = mkdir(argv[1], 0777);
    ERROR_CHECK(ret, -1, "mkdir");

    return 0;
}

