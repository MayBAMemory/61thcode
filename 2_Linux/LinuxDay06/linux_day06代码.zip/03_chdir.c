#include <61header.h>

/* Usage: ./03_chdir dirname  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    char path[1024] = { 0 };
    
    // 打印改变前的工作目录
    char *ret = getcwd(path, sizeof(path));
    ERROR_CHECK(ret, NULL, "getcwd");
    printf("切换前当前工作目录是: %s\n", path);

    // 改变当前工作目录
    int ret2 = chdir(argv[1]);
    ERROR_CHECK(ret2, -1, "chdir");


    // 打印改变后的工作目录
    char *ret3 = getcwd(path, sizeof(path));
    ERROR_CHECK(ret3, NULL, "getcwd");
    printf("切换后的工作目录是: %s\n", path);

    return 0;
}

