#include <61header.h>

/* Usage: ./07_myls_simp dirname  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    DIR* dirp = opendir(argv[1]);
    ERROR_CHECK(dirp, NULL, "opendir");

    // 解决方法1：切换工作目录为要打印信息的目录
    //int ret = chdir(argv[1]);
    //ERROR_CHECK(ret, -1, "chdir");

    struct dirent *dp;
    while((dp = readdir(dirp)) != NULL){
        struct stat stat_buf;
        // 循环处理目录项，把文件名直接作为路径名传参给stat函数
        // 这里需要配合解决办法1
        //int ret = stat(path, &stat_buf);
        // ERROR_CHECK(ret, -1, "stat");

        // 解决办法2：拼接文件的绝对路径然后再传参给stat函数
        char path[1024] = { 0 };
        //strcpy(path, argv[1]);
        //strcat(path, "/");
        //strcat(path, dp->d_name);
        sprintf(path, "%s%s%s", argv[1], "/", dp->d_name);

        int ret = stat(path, &stat_buf);
        ERROR_CHECK(ret, -1, "stat");
        // 获取stat结构体后打印文件的详细信息
        printf("%o %lu %u %u %lu %ld %s\n",
                stat_buf.st_mode,
                stat_buf.st_nlink,
                stat_buf.st_uid,
                stat_buf.st_gid,
                stat_buf.st_size,
                //stat_buf.st_mtim.tv_sec,
                stat_buf.st_mtime,
                dp->d_name
               );
    }
    closedir(dirp);
    return 0;
}

