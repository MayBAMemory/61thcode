#include <61header.h>

/* Usage: ./08_myls dirname */
int main(int argc, char *argv[]){
    char *path;
    if(argc == 1){
        path = ".";
    }else if(argc == 2){
        path = argv[1];
    }else{
        fprintf(stderr, "args nums error!\n");
        return 1;
    }

    // path是一个目录的路径名
    DIR* dirp = opendir(path);
    ERROR_CHECK(dirp, NULL, "opendir");

    // 切换工作目录为待打印的目录
    int ret = chdir(path);
    ERROR_CHECK(ret, -1, "chdir");

    struct dirent *dp;
    while((dp = readdir(dirp))!= NULL){
        struct stat sb;
        int ret = stat(dp->d_name, &sb);
        ERROR_CHECK(ret, -1, "stat");
        
        // 1.处理stat的成员st_mode，将它转换成权限和类型字符串
        char tm_str[1024] = {0};
        set_type_mode(sb.st_mode, tm_str);

        // 2.获取用户名和组名
        char *username;
        char *gname;

        // 3.将时间戳转换为时间字符串
        char time_str[1024] = {0};
        set_time(sb.st_mtim.tv_sec, time_str);

        printf("xxxx");
    }
    closedir(dirp);
    return 0;
}

