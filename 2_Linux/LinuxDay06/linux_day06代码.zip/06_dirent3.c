#include <61header.h>

/* Usage: ./06_dirent2 dirname  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    DIR* dirp = opendir(argv[1]);
    ERROR_CHECK(dirp, NULL, "opendir");

    struct dirent *dp;  // 指向目录项结构体的指针
    while((dp =  readdir(dirp)) != NULL){
        // 每一次循环就处理一个目录项
        printf("inode num = %lu " "offset = %ld "
                "reclen = %hu " "type = %u "
                "file name = %s\n",
                dp->d_ino,
                dp->d_off,
                dp->d_reclen,
                dp->d_type,
                dp->d_name
               );
    }   // 当while循环结束时，dp就是空指针
    
    printf("----------------------------\n");
    rewinddir(dirp);
    dp = readdir(dirp);
    printf("inode num = %lu " "offset = %ld "
        "reclen = %hu " "type = %u "
        "file name = %s\n",
        dp->d_ino,
        dp->d_off,
        dp->d_reclen,
        dp->d_type,
        dp->d_name
       );

    // 不要忘记关闭流
    int ret = closedir(dirp);
    ERROR_CHECK(ret, -1, "closedir");
    return 0;
}

