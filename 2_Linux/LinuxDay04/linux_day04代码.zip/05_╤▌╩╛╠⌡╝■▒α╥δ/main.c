#include <stdio.h>
//#define DEBUG

int main(void){
    // 在vim编辑器中实现多行注释,可以采用下列条件编译的方式
#if 0    
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
    printf("hello world!\n");
#endif

    // 条件编译还可以作为一段代码的开关

#ifdef DEBUG
    printf("今天中午去吃黄焖鸡米饭!\n");
    printf("今天中午去吃黄焖鸡米饭!\n");
    printf("今天中午去吃黄焖鸡米饭!\n");
#endif

    return 0;
}

