#include <stdio.h>
#include "header.h"

// 已初始化的全局变量
int global_var_initialized = 100;

// 未初始化的全局变量
int global_var_uninitialized;

// 函数的定义
void my_function(void) {
    printf("This my_function is defined\n");
}

int main(void){
    printf("hello world!\n");
    printf("global_var_initialized = %d\n", global_var_initialized);
    printf("global_var_uninitialized = %d\n", global_var_uninitialized);
    printf("external_global_var = %d\n", external_gvar);
    external_function();
    my_function();

    return 0;
}


