#include <stdio.h>
#include "header.h"

void external_function(void){
    printf("我是外部函数的实现!\n");
}

int external_gvar = 88888888;
