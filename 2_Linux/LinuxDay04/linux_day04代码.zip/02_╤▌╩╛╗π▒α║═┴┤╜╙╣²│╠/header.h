void external_function(void);   // 函数的声明
extern int external_gvar;    // 全局变量的声明，没有定义

