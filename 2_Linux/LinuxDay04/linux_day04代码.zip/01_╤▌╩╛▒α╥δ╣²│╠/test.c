#include <stdio.h>

void test(void){

}

int main(void){
    printf("hello world!\n");
    int a = 10;
    test();
    return 0;
}

