#include <stdio.h>

int test(void){

} // 忘记写return表示函数返回值
int main(void){
    int a = 10; // a局部变量定义了但没有使用
    int b = 20;
    if(b = 0){} // 赋值号作为判等号使用
    int c = test; // 忘记写函数调用的()运算符
    return 0;
}

