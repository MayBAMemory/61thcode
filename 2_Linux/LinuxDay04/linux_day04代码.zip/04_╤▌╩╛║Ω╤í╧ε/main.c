#include <stdio.h>

int main(void){
    printf("N = %d\n", N);
    return 0;
}

