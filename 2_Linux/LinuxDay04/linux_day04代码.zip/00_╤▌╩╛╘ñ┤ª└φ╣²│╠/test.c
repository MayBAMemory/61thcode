#include <stdio.h>

#define N 10
#define ADD(a, b)((a) + (b))
int main(void){
    printf("hello world!\n");
    printf("N = %d\n", N);
    int res = ADD(1, 1);
    return 0;
}

