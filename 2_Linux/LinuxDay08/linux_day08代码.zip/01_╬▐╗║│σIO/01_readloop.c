#include <61header.h>

/* Usage: ./01_readloop filename */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = open(argv[1], O_RDWR);
    ERROR_CHECK(fd, -1, "open");

    // 为了避免乱码出现，数组元素最好初始化为0值
    char buf[4] = { 0 };

    int read_count;
    while((read_count = read(fd, buf, sizeof(buf) - 1)) > 0 ){
        printf("read_count = %d\n", read_count);
       //printf("buf = %.*s\n",read_count, buf );
       puts(buf);
       // 每读一次后，对于下一次读，buf中的数据都是垃圾数据
       // 所以要清零此buf数组
       memset(buf, 0, sizeof(buf));
    }

    close(fd);

    return 0;
}

