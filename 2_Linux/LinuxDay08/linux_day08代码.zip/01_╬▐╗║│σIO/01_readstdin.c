#include <61header.h>

/* Usage: ./01_readstdin */
int main(void){
    // 为了避免乱码出现，数组元素最好初始化为0值
    char buf[1024] = { 0 };
    // 建议使用标准流的文件描述符时，选择宏定义，不要直接写整数
    ssize_t read_count = read(STDIN_FILENO, buf, sizeof(buf) - 1);
    ERROR_CHECK(read_count, -1, "read");

    printf("read_count = %ld\n", read_count);
    puts(buf);
    
    return 0;
}

