#include <61header.h>

#define BUFFER_SIZE (1024 * 1024 * 7)

/* Usage: ./04_filecp srcname destname */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 3);
    int src_fd = open(argv[1], O_RDONLY);
    ERROR_CHECK(src_fd, -1, "open src");

    int dest_fd = 
        open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0666);
    ERROR_CHECK(dest_fd, -1, "open dest");    

    char buf[BUFFER_SIZE];
    ssize_t read_count;
    while((read_count = read(src_fd, buf,sizeof(buf))) > 0 ){
        write(dest_fd, buf, read_count);
    }
    close(src_fd);
    close(dest_fd);

    return 0;
}

