#include <61header.h>

/* Usage: ./01_read filename */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = open(argv[1], O_RDWR);
    ERROR_CHECK(fd, -1, "open");

    // 为了避免乱码出现，数组元素最好初始化为0值
    char buf[1024] = { 0 };
    ssize_t read_count = read(fd, buf, sizeof(buf) - 1);
    ERROR_CHECK(read_count, -1, "read");

    printf("read_count = %ld\n", read_count);
    puts(buf);
    
    close(fd);
    return 0;
}

