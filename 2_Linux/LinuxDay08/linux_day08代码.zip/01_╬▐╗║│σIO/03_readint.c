#include <61header.h>

/* Usage: ./03_readint filename */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = 
        open(argv[1], O_RDONLY);
    ERROR_CHECK(fd, -1, "open");

    // 需要把字符串转换成int整数
    int num;
    int read_count = read(fd, &num, sizeof(num));
    printf("read_count = %d\n", read_count);
    printf("读出来的整数是：%d\n", num);

    close(fd);
    return 0;
}

