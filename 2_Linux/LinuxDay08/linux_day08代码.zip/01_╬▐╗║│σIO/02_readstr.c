#include <61header.h>

/* Usage: ./02_readstr filename */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = 
        open(argv[1], O_RDONLY);
    ERROR_CHECK(fd, -1, "open");

    char buf[1024] = { 0 };
    int read_count = read(fd, buf, sizeof(buf) - 1);
    ERROR_CHECK(read_count, -1, "read");
    printf("从文件中读出字符串是：%s\n", buf);

    // 需要把字符串转换成int整数
    int num;
    sscanf(buf, "%d", &num);
    printf("将字符串转换成整数是：%d\n", num);

    close(fd);
    return 0;
}

