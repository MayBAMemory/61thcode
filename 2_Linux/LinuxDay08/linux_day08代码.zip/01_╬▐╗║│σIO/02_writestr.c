#include <61header.h>

/* Usage: ./02_writestr filename */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = 
        open(argv[1], O_WRONLY | O_CREAT | O_TRUNC, 0666);
    ERROR_CHECK(fd, -1, "open");

    char src[] = "777777";
    int write_count = write(fd, src, strlen(src));
    ERROR_CHECK(write_count, -1, "write");

    printf("write_count = %d\n", write_count);

    close(fd);
    return 0;
}

