#include <61header.h>

/* Usage: ./00_ftruncate filename filelen */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 3);
    int fd = 
        open(argv[1], O_RDWR | O_CREAT, 0666);
    ERROR_CHECK(fd, -1, "open");

    int len;
    sscanf(argv[2], "%d", &len);
    int ret = ftruncate(fd, len);
    ERROR_CHECK(ret, -1, "ftruncate");

    close(fd);
    return 0;
}

