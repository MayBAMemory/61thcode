#include <61header.h>

/* Usage: ./02_write_upper filename */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = open(argv[1],O_RDWR);
    ERROR_CHECK(fd, -1, "open");

    char ch;
    while(1){
        int read_count = read(fd, &ch, sizeof(ch));
        if(read_count == 0){
            break;
        }
        char ch_upper = toupper(ch);
        // 每读一次，应该让读写位置的指针向文件开头移动1个字节
        lseek(fd, -1, SEEK_CUR);
        write(fd, &ch_upper, sizeof(ch_upper));
    }
    
    close(fd);
    return 0;
}

