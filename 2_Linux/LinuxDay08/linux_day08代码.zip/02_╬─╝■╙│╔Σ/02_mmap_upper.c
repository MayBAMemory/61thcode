#include <61header.h>

/* Usage: ./02_mmap_upper filename */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = open(argv[1],O_RDWR);
    ERROR_CHECK(fd, -1, "open");

    char *p = 
        (char*)mmap(NULL, 11,PROT_READ | PROT_WRITE, MAP_SHARED ,fd,0);
    ERROR_CHECK(p, MAP_FAILED, "mmap");

    for(int i = 0; i < 11; i++){
        p[i] = toupper(p[i]);
    }

    // mmap映射的内存区域，也需要释放，类似free函数
    munmap(p, 11);
    
    close(fd);
    return 0;
}

