#include <61header.h>

#define BUFFER_SIZE (1024 * 1024 * 8)

/* Usage: ./03_mmap_cp srcname destname */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 3);
    int src_fd = open(argv[1],O_RDONLY);
    ERROR_CHECK(src_fd, -1, "open src");

    int dest_fd = 
        open(argv[2],O_RDWR | O_CREAT | O_TRUNC, 0666);
    ERROR_CHECK(dest_fd, -1, "open dest");

    // 求源文件大小
    off_t src_size = lseek(src_fd, 0, SEEK_END);

    // 现在文件读写的指针已经移动到源文件末尾了，需要移回来吗？
    // 不需要 因为mmap和文件对象是没有关系的
    // 因为是大文件复制，所以需要先为目标文件占位
    int ret = ftruncate(dest_fd, src_size);
    ERROR_CHECK(ret, -1, "ftruncate dest");

    // 开始mmap文件分段循环复制的过程
    off_t bytes_copied = 0;         // 当前已复制的字节数量
    while(bytes_copied < src_size){
        // 1.确定这一次映射复制，需要复制的字节数量
        off_t curr_size = ((bytes_copied + BUFFER_SIZE) > src_size)?
            (src_size - bytes_copied) :     // 最后一次复制
            BUFFER_SIZE;        // 不是最后一次复制

        // 2.分别映射src和dest两个文件的一段到内存中
       void* srcp =  mmap(NULL, curr_size, PROT_READ, MAP_SHARED, src_fd, bytes_copied);
       ERROR_CHECK(srcp, MAP_FAILED, "mmap src");
       void* destp =  mmap(NULL, curr_size, PROT_WRITE, MAP_SHARED, dest_fd, bytes_copied);
       ERROR_CHECK(destp, MAP_FAILED, "mmap dest");

        // 3.执行内存复制操作memcpy
        memcpy(destp, srcp, curr_size);
            
        // 4.解除src和dest的映射区域，以释放内存
        munmap(srcp, curr_size);
        munmap(destp, curr_size);
            
        // 5.不要忘记更新bytes_copied变量
        bytes_copied += curr_size;
    }

    close(src_fd);
    close(dest_fd);
    return 0;
}

