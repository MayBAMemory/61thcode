#include <61header.h>

/* Usage: ./01_mmap filename  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = open(argv[1],O_WRONLY);
    ERROR_CHECK(fd, -1, "open");
    
    // ftruncate不是必须的，要看情况
    //int ret = ftruncate(fd, 5);
    //ERROR_CHECK(ret, -1, "ftruncate");

    // 从文件的开头映射5个字节的数据到内存中
    // 假如文件是一个文本文件
    char *p = 
        (char*)mmap(NULL, 5, PROT_WRITE,
                    MAP_SHARED, fd, 0);
    ERROR_CHECK(p, MAP_FAILED, "mmap");

    // 修改一下文件数据
    p[4] = 'a';

    // 遍历文件的数据（文本数据）
    //for(int i = 0; i < 5; i++){
    //    printf("%c ", p[i]);
    //}
    //printf("\n");

    close(fd);
    return 0;
}

