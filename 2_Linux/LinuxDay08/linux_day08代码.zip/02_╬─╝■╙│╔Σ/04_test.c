#include <61header.h>

#if 0
假如opon文件时，打开模式是可读可写，新建了一个文件
但文件没有任何权限
那么后续的读写操作，受不受影响？

不受影响
文件的打开模式优先于文件的自身权限
只要文件能打开，那么打开模式指示的权限就一定可以执行

#endif

/* Usage: ./04_test fileanme */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    int fd = open(argv[1],O_RDWR | O_CREAT, 0000);
    ERROR_CHECK(fd, -1, "open");

    char str[] = "你好吗？";
    int write_count = write(fd, str, strlen(str));
    ERROR_CHECK(write_count, -1, "write");

    lseek(fd, 0, SEEK_SET);

    char buf[1024] = { 0 };
    int read_count = read(fd, buf, sizeof(buf) - 1);
    ERROR_CHECK(read_count, -1, "read");
    
    printf("文件中的内容是：%s\n", buf);
    close(fd);
    return 0;
}

