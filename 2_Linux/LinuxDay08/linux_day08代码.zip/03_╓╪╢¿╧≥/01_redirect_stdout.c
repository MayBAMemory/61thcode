#include <61header.h>

/* Usage: ./01_redirect_stdout filename  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    // 重定向标准输出流之前,应当先输出一句
    printf("两情若是长久时!\n");

    // open之间先关闭标准输出文件描述符
    close(STDOUT_FILENO);
    // 此时1这个文件描述符就空出来了, 赶紧open文件
    // 那么1这个文件描述符就分配给这个新打开的文件了
    int fd = open(argv[1],O_RDWR);
    ERROR_CHECK(fd, -1, "open");
    
    printf("fd = %d\n", fd);
    printf("又岂在朝朝暮暮!\n");
    fflush(stdout);

    close(fd);
    return 0;
}

