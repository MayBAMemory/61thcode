#include <61header.h>

/* Usage: ./01_redirect_stdin filename  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    // open之间先关闭标准输入文件描述符
    close(STDIN_FILENO);
    // 此时0这个文件描述符就空出来了, 赶紧open文件
    // 那么0这个文件描述符就分配给这个新打开的文件了
    int fd = open(argv[1],O_RDWR);
    ERROR_CHECK(fd, -1, "open");
    
    int num;
    scanf("%d", &num);
    printf("fd = %d\n", fd);
    printf("num = %d\n", num);

    close(fd);
    return 0;
}

