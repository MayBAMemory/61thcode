#include <61header.h>

/* Usage: ./00_fopen filename  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    FILE *fp = fopen(argv[1],"w+");
    ERROR_CHECK(fp, NULL, "fopen");
    
    // 用read和write系统调用函数来操作fopen打开的文件
    //int fileno = fp->_fileno;
    int fn = fileno(fp);
    int ret = write(fn, "hello", 5);
    ERROR_CHECK(ret, -1, "write");

    close(fn);
    return 0;
}

