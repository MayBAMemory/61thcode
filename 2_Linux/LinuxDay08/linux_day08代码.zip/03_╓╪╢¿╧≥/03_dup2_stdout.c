#include <61header.h>

/* Usage: ./03_dup2_stdout filename  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    printf("我也不知写什么,就这样吧!\n");
    
    int fd = open(argv[1],O_RDWR);
    ERROR_CHECK(fd, -1, "open");
    
    // 直接利用dup2函数将fd文件描述符复制
    // 指定新的文件描述符是1
    // 此时1已经被占用,dup2会先关闭它,然后再复制
    int new_fd = dup2(fd, STDOUT_FILENO);
    ERROR_CHECK(new_fd, -1, "dup2");

    printf("new_fd = %d\n", new_fd);
    printf("那就这样吧!\n");

    close(fd);
    close(new_fd);
    return 0;
}

