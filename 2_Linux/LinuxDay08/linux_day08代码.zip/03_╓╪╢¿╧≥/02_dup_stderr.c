#include <61header.h>

/* Usage: ./02_dup_stder filename  */
int main(int argc, char *argv[]){
    ARGS_CHECK(argc, 2);
    fprintf(stderr, "我真的错了,但我不知道哪里错了!\n");
    
    int fd = open(argv[1],O_RDWR);
    ERROR_CHECK(fd, -1, "open");
    
    // 关闭标准错误
    close(STDERR_FILENO);

    // 立刻复制文件描述符fd,此时2就是最小可用的文件描述
    // 于是2和3两个文件描述符都指向open函数打开的文件对象
    int new_fd = dup(fd);
    ERROR_CHECK(new_fd, -1, "dup");

    fprintf(stderr, "new_fd = %d\n", new_fd);
    fprintf(stderr, "不知道哪里就是一种错误!\n");

    close(fd);
    close(new_fd);
    return 0;
}

