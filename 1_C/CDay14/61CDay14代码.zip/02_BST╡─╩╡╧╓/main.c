#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ARR_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))
#include "BST.h"

int main(void) {
	BST *tree = bst_create();
	// ��һ��
	bst_insert(tree, 30);
	bst_insert(tree, 10);
	bst_insert(tree, 40);
	
	// �ڶ���
	bst_insert(tree, 5);
	bst_insert(tree, 15);
	bst_insert(tree, 35);
	bst_insert(tree, 70);

	// ������
	bst_insert(tree, 3);
	bst_insert(tree, 12);
	bst_insert(tree, 75);

	// ��ʾ����
	//bst_preorder(tree);


	bst_levelorder2(tree);

	//TreeNode *ret = bst_search(tree, 3);
	//TreeNode *ret2 = bst_search(tree, 40);
	//TreeNode *ret3 = bst_search(tree, 100);

	//bst_delete(tree, 30);

	return 0;
}