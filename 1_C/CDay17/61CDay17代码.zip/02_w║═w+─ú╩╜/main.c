#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ARR_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

int main(void) {
	FILE* fp = fopen("1.txt", "w");
	if (fp == NULL) {
		printf("�ļ���ʧ��!\n");
		return 1;
	}

	fclose(fp);
	return 0;
}