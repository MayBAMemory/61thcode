#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

int main(void) {
	char *file = "1.txt";
	FILE* fp = fopen(file, "r");
	/*if (fp == NULL) {
		fprintf(stderr, "errno = %d\n", errno);
		fprintf(stderr, "errmsg = %s\n", strerror(errno));
		exit(-1);
	}*/

	// �������ô������ı�׼��ʽ
	if (fp == NULL) {
		perror(file);
		exit(-1);
	}

	fclose(fp);
	return 0;
}