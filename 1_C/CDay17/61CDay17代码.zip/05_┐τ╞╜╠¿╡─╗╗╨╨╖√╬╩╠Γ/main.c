#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ARR_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

int main(void) {
	FILE *fp = fopen("1.txt", "rb+");
	if (fp == NULL) {
		printf("�ļ���ʧ��!\n");
		return 1;
	}
	//int ch = fgetc(fp);
	//int ch2 = fgetc(fp);
	//int ch3 = fgetc(fp);

	fputc('1', fp);
	fputc('\n', fp);
	fputc('2', fp);

	fclose(fp);
	return 0;
}