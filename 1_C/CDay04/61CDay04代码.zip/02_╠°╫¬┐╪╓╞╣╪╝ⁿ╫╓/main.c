#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {

	//int count = 0;
	//int sum = 0;
	//int i;
	//while (count < 5) {
	//	scanf("%d", &i);
	//	if (i == 0) {
	//		// ����0�Ͳ���Ҫ�ۼ���
	//		continue;
	//	}
	//	sum += i;
	//	count++;
	//}
	//printf("sum = %d\n", sum);


	int sum = 0;
	int i;
	for (int count = 0; count < 5; count++) {
		scanf("%d", &i);
		if (i == 0) {
			// ����0�Ͳ���Ҫ�ۼ���
			continue;
		}
		sum += i;
	}
	printf("sum = %d\n", sum);

	return 0;
}