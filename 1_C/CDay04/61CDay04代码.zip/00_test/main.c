#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {
	//int a = (1,3);
	//int ch = getchar();
	char ch2 = -1;
	printf("%c\n", ch2);
	return 0;
}