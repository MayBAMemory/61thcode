#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int test(void) {
	return 777;
}
int main(void) {
	const int a = 10;
	//a = 100;
	const int arr[] = { 1, 2, 3 };
	//arr[2] = 100;

	const int len = 10;
	//int arr2[len];
	//scanf("%d", &len);
	int *p = &len;
	*p = 1000;

	const int ret = test();

	return 0;
}