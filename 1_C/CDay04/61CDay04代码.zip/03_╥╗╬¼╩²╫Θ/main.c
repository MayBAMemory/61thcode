#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

//#define ARR_LEN 5

int main(void) {
	//int arr[ARR_LEN];
	/*int arr[] = { 1, 2, 3, 4, 5 };
	int arr2[10] = { 0 };
	int arr3[] = { 0 };
	int arr4[5] = { 1 };*/


	int arr[] = { 1, 2, 3, 4, 5 };
	arr[3];

	return 0;
}