#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct node {
	int data;
	struct node *next;
} Node;

void insert_tail(Node **head, int val) {
	Node *new_node = calloc(1, sizeof(Node));
	if (new_node == NULL) {
		printf("malloc failed in insert_tail.\n");
		exit(1);
	}
	new_node->data = val;
	if (*head == NULL) {
		*head = new_node;
	}
	else {
		Node *curr = *head;
		while (curr->next != NULL) {
			curr = curr->next;
		}
		curr->next = new_node;
	}
}

void print_list(Node *head) {
	Node *curr = head;
	while (curr != NULL) {
		printf("%d -> ", curr->data);
		curr = curr->next;
	}
	printf("NULL\n");
}

// ��ת��ǰ�������������µ�ͷָ��
Node *reverse_loop_solution(Node *head) {
	Node *prev = NULL;
	Node *curr = head;
	Node *succ = curr->next;	// succʼ��ָ��curr�ĺ�̽��

	while (curr != NULL) {
		succ = curr->next;
		curr->next = prev;	// ��ת�ĺ��Ĳ���
		prev = curr;
		curr = succ;
	}	// whileѭ������ʱ,currָ��NULL,prev��ָ���µĵ�һ�����
	return prev;
}

Node *reverse_loop_solution2(Node *head) {
	Node *prev = NULL;
	Node *curr = head;

	while (curr != NULL) {
		Node *succ = curr->next;
		curr->next = prev;	// ��ת�ĺ��Ĳ���
		prev = curr;
		curr = succ;
	}	// whileѭ������ʱ,currָ��NULL,prev��ָ���µĵ�һ�����
	return prev;
}

Node *reverse_recursion_solution(Node *head) {
	// 1.�ݹ�ĳ���
	if (head == NULL || head -> next == NULL){
		return head;
	}
	// 2.�ݹ���
	Node *new_head = reverse_recursion_solution(head->next);
	head->next->next = head;
	head->next = NULL;
	return new_head;
}

int main(void) {
	Node *head = NULL;

	insert_tail(&head, 1);
	insert_tail(&head, 2);
	insert_tail(&head, 3);
	insert_tail(&head, 4);
	insert_tail(&head, 5);
	insert_tail(&head, 6);
	
	//head = reverse_loop_solution2(head);
	//print_list(head);
	head = reverse_recursion_solution(head);
	print_list(head);
	return 0;
}