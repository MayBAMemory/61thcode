#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define N 100
#define PI 3.1415926
#define ARR_SIZE 10

#define SQUARE_DIFF(x, y) ((x) * (x) - (y) * (y))

int main(void) {
	printf("N = %d\n", N);
	int arr[10] = { 1 };	// ����ħ�������淶
	int arr2[ARR_SIZE] = { 1 };	// �淶��д��

	printf("3^2 - 2^2 = %d\n", SQUARE_DIFF(3, 1 + 1));
	printf("(3^2 - 2^2) * 100 = %d\n", SQUARE_DIFF(3, 2) * 100);
	return 0;
}