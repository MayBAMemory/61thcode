#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void test(void);

int main(void) {
	test();
	return 0;
}