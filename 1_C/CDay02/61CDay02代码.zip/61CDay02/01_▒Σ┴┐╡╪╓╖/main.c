#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "test.h"

void test(void) {}
int main(void) {
	//int a = 999;
	int num = 777;

	return 0;
}