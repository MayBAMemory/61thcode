#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "test.h"

int main(void) {
	test();
	return 0;
}