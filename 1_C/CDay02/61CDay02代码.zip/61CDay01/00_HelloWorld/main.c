#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
/*

*/
int main(void) {
	printf("hello world!\n");
	return 0;
}