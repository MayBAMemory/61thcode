#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {
	char ch = 'a';
	char ch2 = '0';
	char ch3 = 97;
	char ch4 = 128;
	return 0;
}