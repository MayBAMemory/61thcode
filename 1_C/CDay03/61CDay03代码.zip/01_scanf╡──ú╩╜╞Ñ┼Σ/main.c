#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {
	int i, j;
	float x, y;
	scanf("%d%d%f%f", &i, &j, &x, &y);
	fflush(stdin);

	char ch;
	scanf(" %c", &ch);

	return 0;
}