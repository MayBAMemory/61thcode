#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ARR_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))
#include "linked_list.h"

int main(void) {
	LinkedList *list = create_linked_list();
	if (list == NULL) {
		printf("create_linked_list failed in main.\n");
		return 1;
	}

	add_before_head(list, 3);
	add_before_head(list, 2);
	add_before_head(list, 1);
	print_list(list);
	add_behind_tail(list, 4);
	add_behind_tail(list, 5);
	print_list(list);

	add_by_idx(list, 0, 0);
	print_list(list);
	add_by_idx(list, list->size, 6);
	print_list(list);

	add_by_idx(list, 3, 10);
	print_list(list);

	delete_by_idx(list, 3);
	print_list(list);

	delete_by_idx(list, 0);
	print_list(list);

	delete_by_idx(list, 5);
	print_list(list);

	destroy_linked_list(list);
	return 0;
}