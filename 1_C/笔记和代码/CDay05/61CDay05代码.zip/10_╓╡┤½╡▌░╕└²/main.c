#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void swap_num(int a, int b) {
	int tmp = a;
	a = b;
	b = tmp;
	printf("swap�����ڲ�-------------\n");
	printf("a = %d\n", a);
	printf("b = %d\n", b);
	printf("swap�����ڲ�-------------\n");
}
int main(void) {
	int a = 10, b = 20;
	swap_num(a, b);
	printf("a = %d\n", a);
	printf("b = %d\n", b);
	return 0;
}