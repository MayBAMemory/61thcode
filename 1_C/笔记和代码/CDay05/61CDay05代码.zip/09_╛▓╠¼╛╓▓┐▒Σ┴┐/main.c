#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int get_id(void) {
	static int id = 0;
	return id++;
}
int main(void) {
	for (int i = 0; i < 10; i++) {
		printf("%d\n", get_id());
	}
	return 0;
}