#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

static int g_a = 10;
static int g_b = 20;

void swap(int a, int b) {
	int tmp = a;
	a = b;
	b = tmp;
	printf("swap�����ڲ�-------------\n");
	printf("a = %d\n", a);
	printf("b = %d\n", b);
	printf("swap�����ڲ�-------------\n");
}

void swap2() {
	int tmp = g_a;
	g_a = g_b;
	g_b = tmp;
}

int main(void) {
	//swap(g_a, g_b);
	swap2(g_a, g_b);
	printf("g_a = %d\n", g_a);
	printf("g_b = %d\n", g_b);
	return 0;
}