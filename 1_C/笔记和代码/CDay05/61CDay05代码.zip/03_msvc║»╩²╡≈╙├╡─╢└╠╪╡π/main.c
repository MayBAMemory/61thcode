#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {
	//test();
	func();
	return 0;
}

int test(void) {
	return 1;
}

void func(void) {
	return 1;
}