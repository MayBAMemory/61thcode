#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ARR_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

int main(void) {
	int a = 10;
	int *p = &a;
	void *void_p = &a;

	printf("%p\n", p);
	printf("%p\n", void_p);

	//int num = *void_p; �޷�������ͨ��ָ������
	int *p2 = void_p;
	printf("%d\n", *p2);

	return 0;
}