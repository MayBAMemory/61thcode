#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ARR_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

typedef struct {
	int x;
	int y;
} Node;

int main(void) {
	int *p = calloc(10, sizeof(int));
	//int *p = malloc(10);
	if (p == NULL) {
		printf("error: calloc failed in main.\n");
		exit(-1);
	}
	for (int i = 0; i < 10; i++) {
		printf("%d\n", p[i]);
	}
	free(p);

	Node *p2 = calloc(1, sizeof(Node));
	if (p2 == NULL) {
		printf("error: calloc failed in main.\n");
		exit(-1);
	}
	free(p2);

	return 0;
}