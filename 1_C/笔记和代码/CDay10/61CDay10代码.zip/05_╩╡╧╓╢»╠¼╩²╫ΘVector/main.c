#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ARR_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))
#include "vector.h"

int main(void) {
	// ����Vector
	Vector *v = vector_create();
	if (v == NULL) {
		printf("error: ����Vectorʧ��!\n");
		return 1;
	}
	/*vector_push_back(v, 1);*/
	for (int i = 0; i < 2000; i++) {
		vector_push_back(v, i + 1);
	}
	vector_print(v);


	vector_destroy(v);
	return 0;
}