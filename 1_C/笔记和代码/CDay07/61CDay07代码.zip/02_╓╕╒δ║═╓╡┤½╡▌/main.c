#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void swap_by_ptr(int *p1, int *p2) {
	int tmp = *p1;
	*p1 = *p2;
	*p2 = tmp;
}

int main(void) {
	int a = 10; 
	int b = 20;
	swap_by_ptr(&a, &b);

	return 0;
}