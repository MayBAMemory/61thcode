#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void test(int arr[], int len) {
	arr = NULL;
}
// ��ȫ�ȼ���
void test2(int *arr, int len) {
	arr[0] = 100;
}
int main(void) {
	int arr[] = { 1, 2, 3, 4 };

	//arr = arr2;
	//arr = NULL;
	return 0;
}