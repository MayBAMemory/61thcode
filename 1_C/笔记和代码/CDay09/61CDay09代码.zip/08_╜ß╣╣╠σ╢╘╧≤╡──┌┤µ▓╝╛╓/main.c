#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

typedef struct student {
	int stu_id;
	char name[25];
	char gender;
	int chinese;
	int math;
	int english;
} Student;

int main(void) {
	Student s = { 100, "faker", 'm', 100, 100, 100 };

	return 0;
}