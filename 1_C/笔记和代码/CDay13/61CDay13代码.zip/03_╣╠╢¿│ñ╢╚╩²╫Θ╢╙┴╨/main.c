#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ARR_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

#include "array_queue.h"

int main(void) {
	ArrayQueue *queue = queue_create();
	for (size_t i = 0; i < 20; i++) {
		enqueue(queue, (i + 1));
	}

	for (size_t i = 0; i < 20; i++) {
		ElementType data = dequeue(queue);
		printf("%d�γ����У�Ԫ����: %d\n", i + 1, data);
	}
	queue_destroy(queue);
	return 0;
}