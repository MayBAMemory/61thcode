#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>


long long hanoi_count(int n) {
	if (n == 1) {
		return 1;
	}
	return 2 * hanoi_count(n - 1) + 1;
}

int main(void) {
	long long ret = hanoi_count(10);
	printf("count = %lld\n", ret);
	
	long long count = (1LL << 10) - 1;
	printf("count = %lld\n", count);
	return 0;
}